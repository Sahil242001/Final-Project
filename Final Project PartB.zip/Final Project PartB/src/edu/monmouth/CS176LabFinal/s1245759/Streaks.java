package edu.monmouth.CS176LabFinal.s1245759;

public interface Streaks 
{
enum Streak 
{
	Win,
	Loss,
	None
}
void winstreaks();
void lossstreaks();
 
}
