package edu.monmouth.CS176LabFinal.s1245759;

import java.util.ArrayList;

public class Team implements Streaks, Comparable<Team>
{
	public int teamID;
	public String teamName;
	public String teamHometown;
	public String teamContact;
	
	// instance variables to track W, L, PF, PA and Win%
	
	private int win;
	private int loss;
	private int pointsFor;
	private int pointsAgainst;
	private double winningPercentage;
	
	// an ArrayList to track team's results
	
	public ArrayList<Game> teamResults = new ArrayList<Game> ();
	
	// Constructor
	
	Team (int id, String name, String town, String contact) {
		this.teamID = id;
		this.teamName = name;
		this.teamHometown = town;
		this.teamContact = contact;
		
		// initialize the additional instance variables
		this.win = 0;
		this.loss = 0;
		this.pointsFor = 0;
		this.pointsAgainst = 0;
		this.winningPercentage = 0.00;
				
	}
	
	// method to process a result for a team
	
	public void addTeamGameResult (Game g) {
		
		teamResults.add(g);  // add the result to teamResults ArrayList
		
		// need to process this game for win, loss, PF, PA
		
		if (g.teamA == this.teamID) {  // we're are team A
			
			if (g.teamAscore > g.teamBscore) { // we won
				this.recordWin();
			} else {                            // we lost
				this.recordLoss();
			}
			recordPointsFor ( g.teamAscore); // record PF
			recordPointsAgainst( g.teamBscore) ; // record PF
			
		} 
		else {  // we are team B
			
			if (g.teamBscore > g.teamAscore) {  // we won
				this.recordWin();
			} else {                            // we lost
				this.recordLoss();
			}
			recordPointsFor ( g.teamBscore);  // record PF
			recordPointsAgainst( g.teamAscore) ; // record PA
			
		}
		
		
	}
	
	// getter methods
	
	public int getWin () {
		return this.win;
	}
	
	public int getLoss () {
		return this.loss;
	}
	
	public int getPF () {
		return this.pointsFor;
	}
	
	public int getPA () {
		return this.pointsAgainst;
	}
	
	public double getWinPercentage () {
		return this.winningPercentage;
	}
	
	// Compute the winning percentage
	
	public void computeWinningPercentage () {
		if ((this.win + this.loss) > 0) {
			this.winningPercentage = this.win/(double) (this.win + this.loss);
		}
	}
	
	// record the win
	
	public void recordWin() {
		this.win++;     // increment W
		computeWinningPercentage();
	}
	
	// record the loss
	public void recordLoss() {
		this.loss++;  // increment L
		computeWinningPercentage();
	}
	
	// record PF and PA - just add this games score to PF and PA
	
	public void recordPointsFor (int points) {this.pointsFor += points;}
	public void recordPointsAgainst (int points) {this.pointsAgainst += points;}

	// 2 level comparison - 1st based on win%. On tie, use PF
	
	public int compareTo(Team o) {
		if (this.winningPercentage > o.winningPercentage) {
			return 1;
		} else if (this.winningPercentage < o.winningPercentage) {
			return -1;
		}
		
		// W % is equal
		// secondary sort based on PF
		
		if (this.pointsFor > o.pointsFor) {
			return 1;
		} else if (this.pointsFor < o.pointsFor) {
			return -1;
		}
		
		return 0;
		
	}
	
	
	
	// formatted outout of team contact info
	public void showTeamInfo() {
		System.out.printf ("%-20s %n", "TEAM INFORMATION");
		System.out.printf ("%-6s %-30s %n", "Name:", this.teamName);
		System.out.printf ("%-6s %-30s %n", "Hometown:", this.teamHometown);
		System.out.printf ("%-6s %-30s %n", "Contact:", this.teamContact);
		System.out.println("----------------------------------");	
	}

	@Override
	public void winstreaks() 
	{
		win = 0;	
	}

	@Override
	public void lossstreaks() 
	{
		loss = 0;	
	}

	
	
}
