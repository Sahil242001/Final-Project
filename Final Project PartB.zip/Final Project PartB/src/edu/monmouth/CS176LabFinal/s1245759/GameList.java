package edu.monmouth.CS176LabFinal.s1245759;

import java.util.ArrayList;

public class GameList 
{
public ArrayList<Game> leagueResults = new ArrayList<Game> ();
	
	
	public void addGameResult (Game g) 
	{
		leagueResults.add(g);
		
	}

}
