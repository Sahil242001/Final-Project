package edu.monmouth.CS176LabFinal.s1245759;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class BBallTester 
{
	public static TeamList teams = new TeamList();
	public static GameList games = new GameList();
	
	public static void main(String[] args) {
		readTeamsCSV();
		readGamesCSV();
		processResults();
	    teams.showOverallStandings();
		teams.showTeamStandings();
		
	}
	
	public static void readTeamsCSV () {
		String teamData = "BBallLeague-Teams.csv";
			try {
				Scanner scanner = new Scanner(new File("/Users/sahil24/eclipse-workspace/Final Project PartB//" + teamData));
				int line = 0;
				while (scanner.hasNextLine()) {
					String data = scanner.nextLine();
					if (line > 0) {
						String[] dataFields = data.split(",");
						int teamID = Integer.valueOf(dataFields[0]);
						
						Team newTeam = new Team (teamID, dataFields[1], dataFields[2], dataFields[3]);
						teams.addTeam(newTeam);
					}
					line++;
					
					
				}
				scanner.close();
				
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		
	}
	
	public static void readGamesCSV () {
		
		String teamData = "BBallLeague-GameResults-2.csv";
		
		
		try {
			Scanner scanner = new Scanner(new File("/Users/sahil24/eclipse-workspace/Final Project PartB//" + teamData));
			int line = 0;
			while (scanner.hasNextLine()) {
				String data = scanner.nextLine();
				
				if (line > 0) {
					String[] dataFields = data.split(",");
					
					// String to integer conversion since Game data is all integers
					
					int week = Integer.valueOf(dataFields[0]);
					int teamAid = Integer.valueOf(dataFields[1]);
					int teamBid = Integer.valueOf(dataFields[2]);
					int teamAscore = Integer.valueOf(dataFields[3]);
					int teamBscore = Integer.valueOf(dataFields[4]);
					
				    Game newGame = new Game (week, teamAid, teamBid, teamAscore, teamBscore);
					games.addGameResult(newGame);
				}
				line++;
				
			}
			scanner.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	
	}
	
	public static void processResults() {
		for (Game g: games.leagueResults) {
			Team teamA = teams.findTeam(g.teamA);
			Team teamB = teams.findTeam(g.teamB);
			if ((teamA != null) && (teamB != null)) {
				teamA.addTeamGameResult(g);
				teamB.addTeamGameResult(g);
			}
		}
	}
	
	public static void main1(String[] args) 
	{
		Scanner userInput = new Scanner (System.in);
		String action = " ";
		boolean Quit = false;
		do 
		{
			System.out.print ("Enter New (T)eam Stats, (Q)uit: ");
			action = userInput.nextLine();
			switch (action) 
			{
			case "Q":
				Quit = true;
				break;
			case "T":
				System.out.println("TeamStats");
				teamName(userInput);
				break;
			default:
				System.out.println ("Invalid Action - Try again");
				break;
		}
		}
			while (!Quit);
			System.out.println("Quit");
			userInput.close();
		}

	private static void teamName(Scanner userInput) 
	{
		System.out.println("Enter Team Name: ");
		String teamName = userInput.nextLine();
		if(teams.findTeamByName(teamName)!=null)
		{
			System.out.println(teams.findTeamByName(teamName));
			
		}
		else
		{
			System.out.println("Team Not Found");
		}
		
	}


}
