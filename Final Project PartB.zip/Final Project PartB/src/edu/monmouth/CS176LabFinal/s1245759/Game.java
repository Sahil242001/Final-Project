package edu.monmouth.CS176LabFinal.s1245759;

public class Game 
{
	public int week;
	public int teamA;
	public int teamB;
	public int teamAscore;
	public int teamBscore;
	
	Game (int week, int teamA, int teamB, int teamAscore, int teamBscore) {
		this.week = week;
		this.teamA = teamA;
		this.teamB = teamB;
		this.teamAscore = teamAscore;
		this.teamBscore = teamBscore;
	}

}
