package edu.monmouth.CS176LabFinal.s1245759;

import java.util.*;

public class TeamList 
{
    public ArrayList<Team> leagueTeams = new ArrayList<Team> ();
	
	// add a team object to list
	
	public void addTeam(Team newTeam) {
		this.leagueTeams.add(newTeam);
	}
	
	// show formatted output of team record
	
	public void showWL(Team t) {
		
		System.out.printf("%-15s", t.teamName);
		System.out.printf("%3d", t.getWin());
		System.out.printf("%3d",t.getLoss() );
		System.out.printf("%5d",t.getPF() );
		System.out.printf("%6d",t.getPA());
		System.out.printf ("%8.2f %n",t.getWinPercentage());
		
	}
	// sort the teams ArrayList using Collections.sort method in descending order
	
	public void showOverallStandings() {
		// specify the reverse order parameter to do descending sort
		
		Collections.sort(leagueTeams, Collections.reverseOrder() );
		
		 
		
		// header for output
		
		System.out.printf("%-15s  %-3s%-3s %-5s %-5s %-4s %n", "Team", "W", "L", "PF", "PA", "Win%");
		// show each team's stats
		for (Team t: this.leagueTeams) {
			showWL(t);	
		}
	}
	
	// methods below are to show individual team stats
	
	public void showTeamStandings() {
		for (Team t: this.leagueTeams) {		
			showTeamData(t);
		}
	}
	
	
	public void showTeamData(Team t) {
		t.showTeamInfo();
		System.out.printf("%-30s %n", "TEAM RECORD");
		System.out.printf("%-15s  %-3s%-3s %-5s %-5s %-4s %n", "Team", "W", "L", "PF", "PA", "Win%");

		showWL(t);
		System.out.println("____________________");
		System.out.println("GAME RESULTS");
		
		System.out.printf("%-5s %-15s %-7s %-6s%n", "Week", "Opponent", "Score", "Result");

		for (Game g: t.teamResults ) {
			
			Team opponent;
			String result;
			
			System.out.printf("%4d  ", g.week);
			
			if (g.teamA == t.teamID) {
				opponent = findTeam (g.teamB);
				result = (g.teamAscore > g.teamBscore) ? "W" : "L";
				System.out.printf("%-15s", opponent.teamName);
				System.out.printf ("%3d%1s%3d %2s %n", g.teamAscore, "-", g.teamBscore, result);
				
			} else {
				opponent = findTeam (g.teamA);
				result = (g.teamBscore > g.teamAscore) ? "W" : "L";
				System.out.printf("%-15s", opponent.teamName);
				System.out.printf ("%3d%1s%3d %2s %n", g.teamBscore, "-", g.teamAscore, result);
			}
			
			
		}
		System.out.println ("-----------------------------------");
		System.out.println ("-----------------------------------");

	}
	
	// find a team given ID
	
	public Team findTeam (int id) 
	{
		Team team = null;
		for (Team t: this.leagueTeams) 
		{
			if (t.teamID == id)
			{
				return t;
			}
		}
		
		return team;
	}
	
	public Team findTeamByName(String teamName)
	{
		Team team = null;
		for(Team t : this.leagueTeams)
		{
			if (t.teamName == teamName)
			{	
				return t;
			}
		}
		return team;
	}
}
